package com.nadia.project1nadiamonika

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView

class TigaActivity : AppCompatActivity() {
    lateinit var rgBayar:RadioGroup
    lateinit var rbBayar:RadioButton

    val asal =
        arrayOf<String>("Padang","Medan","Jakarta","Aceh","Manado")
    val tujuan =
        arrayOf<String>("Jakarta","Singapore","Malaysia","Thailand","Taiwan")
    val jam =
        arrayOf<String>("06.00 AM","08.00 AM","10.00 AM","02.00 PM","04.00 PM")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tiga)
        val id = findViewById<EditText>(R.id.editId)

        rgBayar=findViewById<RadioGroup>(R.id.rgBayar)

        val pel = findViewById<EditText>(R.id.editNamaPelanggan)
        val hTiket = findViewById<EditText>(R.id.editHargatiket)
        val jumlahbeli = findViewById<EditText>(R.id.editJumlahBeli)
        val proses = findViewById<Button>(R.id.btnProsesTiket)
        val transaksi = findViewById<TextView>(R.id.txtTransaksiTiket)

        val asal = findViewById<Spinner>(R.id.spinAsal)
        asal.onItemSelectedListener=this
        val ka:ArrayAdapter<*> = ArrayAdapter<Any?>(this@TigaActivity,
            R.layout.spin_style,asal)
        ka.setDropDownViewResource(R.layout.spin_style)
        asal.adapter=ka

        val tujuan = findViewById<Spinner>(R.id.spinTujuan)
        tujuan.onItemSelectedListener=this
        val kt:ArrayAdapter<*> = ArrayAdapter<Any?>(this@TigaActivity,
            R.layout.spin_style,tujuan)
        kt.setDropDownViewResource(R.layout.spin_style)
        tujuan.adapter=kt

        val jam = findViewById<Spinner>(R.id.spinJamKeberangkatan)
        jam.onItemSelectedListener=this
        val jk:ArrayAdapter<*> = ArrayAdapter<Any?>(this@TigaActivity,
            R.layout.spin_style,jam)
        jk.setDropDownViewResource(R.layout.spin_style)
        jam.adapter=jk

    }

//    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//        TODO("Not yet implemented")
//    }
//
//    override fun onNothingSelected(parent: AdapterView<*>?) {
//        TODO("Not yet implemented")
//    }
}