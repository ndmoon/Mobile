package com.nadia.project1nadiamonika

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var matkul : EditText
    lateinit var dosen : EditText
    lateinit var submit : Button
    lateinit var data : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        matkul = findViewById(R.id.editMatkul)
       // val matkul = findViewById<EditText>(R.id.editMatkul)
        dosen = findViewById(R.id.editDosen)
       // val dosen = findViewById<EditText>(R.id.editDosen)
        submit = findViewById(R.id.btnSubmit)

        data = findViewById(R.id.txtOut)
        submit.setOnClickListener {
            //data.text = ("Data Perkuliahan :\nNama Mata Kuliah :"+matkul.text+"\nDosen Pengampu :"+dosen.text)
            data.setText("Data Perkuliahan "+
            "\nNama Mata Kuliah :"+matkul.text+"\nDosen Pengampu :"+dosen.text)
        }
    }
}