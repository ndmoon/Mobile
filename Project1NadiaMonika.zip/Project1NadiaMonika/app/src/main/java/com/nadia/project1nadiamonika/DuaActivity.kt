package com.nadia.project1nadiamonika

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class DuaActivity : AppCompatActivity(),AdapterView.OnItemSelectedListener {
    val satuan =
        arrayOf<String>("Excecutive","Standart","Economi","President Suite")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dua)
        val kamar = findViewById<EditText>(R.id.editKamar)
        val harga = findViewById<EditText>(R.id.editHarga)
        val hari = findViewById<EditText>(R.id.editHari)
        val biaya = findViewById<EditText>(R.id.editBiaya)
        val proses = findViewById<Button>(R.id.btnProses)
        val output = findViewById<TextView>(R.id.txtOutput)

        val spin = findViewById<Spinner>(R.id.spinTipe)
        spin.onItemSelectedListener=this
        val  aa:ArrayAdapter<*> = ArrayAdapter<Any?>(this@DuaActivity,
            R.layout.spin_style,satuan)
        aa.setDropDownViewResource(R.layout.spin_style)
        spin.adapter=aa

        proses.setOnClickListener {
            var nKamar = kamar.text
            val type = spin.selectedItem
            val hKamar = harga.text.toString().toInt()
            val bTambahan = biaya.text.toString().toDouble()
            val jHari = hari.text.toString().toDouble()
            val total = ( hKamar * jHari ) + bTambahan
            output.setText("Pembayaran Kamar Hotel :\nNo Kamar : $nKamar"+
            "\nHarga Kamar : $hKamar"+
            "\nTipe Kamar : $type"+
            "\nHari Menginap : $jHari"+
            "\nBiaya Tambahan : $bTambahan"+
            "\nTotal Bayar : $total ")
        }
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        val pilihanTipe:String = parent?.getItemAtPosition(position).toString()
        Toast.makeText(this, "Tipe Kamar dipilih : $pilihanTipe",
            Toast.LENGTH_LONG).show()
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}