package com.nadia.storenadiamonika

data class Barang(
    val nama:String,
    val keterangan:String,
    val harga:String,
    val gambar:String,
    val promo:String
)
