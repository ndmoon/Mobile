package com.nadia.storenadiamonika

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.Volley
import com.android.volley.toolbox.StringRequest


class AddDataBarangActivity : AppCompatActivity() {
    lateinit var namaBrg:EditText
    lateinit var keteranganBrg:EditText
    lateinit var hargaBrg:EditText
    lateinit var gambarBrg:EditText
    lateinit var promoBrg:EditText
    lateinit var btnAdd:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_data_barang)
        initViewAdd()


        btnAdd.setOnClickListener {
            sendDataBarang()
        }
    }

    private fun sendDataBarang() {
        val namaBarang = namaBrg.text.toString()
        val keteranganBarang = keteranganBrg.text.toString()
        val hargaBarang = hargaBrg.text.toString()
        val gambarBarang = gambarBrg.text.toString()
        val promoBarang = promoBrg.text.toString()
        addDataBarang(namaBarang, keteranganBarang, hargaBarang, gambarBarang, promoBarang)
    }

    private fun addDataBarang(nama:String, keterangan:String, harga:String, gambar:String, promo:String) {
        val url_add = "https://nadiamonikaputri.000webhostapp.com/add_barang.php"
        val queueAdd = Volley.newRequestQueue(this@AddDataBarangActivity)
        val stringRequest = object:StringRequest(Request.Method.GET, url_add,Response.Listener {
            response -> Toast.makeText(this, "Data barang berhasil ditambahkan", Toast.LENGTH_LONG).show()
            startActivity(Intent(this@AddDataBarangActivity,MainActivity::class.java))
        }, Response.ErrorListener {
            Toast.makeText(this, "Data barang gagal ditambahkan", Toast.LENGTH_LONG).show()
        }
        ){
            override fun getParams(): HashMap<String, String>? {
                val map = HashMap<String, String>()
                map["nama"]= nama
                map["keterangan"]= keterangan
                map["harga"]= harga
                map["gambar"]= gambar
                map["promo"]= promo
                return map
            }
        }
        queueAdd.add(stringRequest)
    }

    private fun initViewAdd() {
        namaBrg = findViewById(R.id.editNama)
        keteranganBrg= findViewById(R.id.editDeskripsi)
        hargaBrg=findViewById(R.id.editHarga)
        gambarBrg=findViewById(R.id.editGambar)
        promoBrg=findViewById(R.id.editPromo)
        btnAdd=findViewById(R.id.btnSimpan)
    }

}