package com.nadia.storenadiamonika

class ConstanUrl {
    private val BASE_URL = "https://nadiamonikaputri.000webhostapp.com/"
}