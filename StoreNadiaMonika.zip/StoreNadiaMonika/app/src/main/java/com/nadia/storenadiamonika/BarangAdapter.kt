package com.nadia.storenadiamonika

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class BarangAdapter(val barangList:ArrayList<Barang>):RecyclerView.Adapter<BarangAdapter.BarangHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BarangHolder {
        val itemView=LayoutInflater.from(parent.context).inflate(R.layout.item_barang,parent, false)
        return BarangHolder(itemView)
    }

    override fun getItemCount(): Int {
       return barangList.size
    }

    override fun onBindViewHolder(holder: BarangHolder, position: Int) {
        holder.namaBrg.text=barangList.get(position).nama
        holder.keteranganBrg.text=barangList.get(position).keterangan
        holder.hargaBrg.text="Harga : Rp."+barangList.get(position).harga
        Picasso.get().load(barangList.get(position).gambar).into(holder.gambarBrg);
        holder.promoBrg.text="Promo : Rp."+barangList.get(position).promo
    }

    class BarangHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var namaBrg: TextView=itemView.findViewById(R.id.txtNama)
        var keteranganBrg: TextView=itemView.findViewById(R.id.txtKeterangan)
        var hargaBrg: TextView=itemView.findViewById(R.id.txtHarga)
        var gambarBrg: ImageView=itemView.findViewById(R.id.imageBarang)
        var promoBrg: TextView=itemView.findViewById(R.id.txtPromo)
        }
    }
